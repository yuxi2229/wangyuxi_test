---
name: "[New Feature]新功能请求"
about: 期望能够增加的功能
title: "[Feature]"
labels: ''
assignees: ''

---

### 功能描述
> 需要实现的功能的描述

### 支援信息
> 出现的页面链接和课程等信息,另外是否可以提供账号,可以在此处留下邮箱
