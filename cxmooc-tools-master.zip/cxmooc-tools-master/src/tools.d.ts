
declare function CAT_click(el: Element): void;

