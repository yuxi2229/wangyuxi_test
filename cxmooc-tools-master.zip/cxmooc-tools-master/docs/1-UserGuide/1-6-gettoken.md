---
title: Token的获取以及使用
---

## 获取Token
关注公众号【叛逆青年旅舍】，回复token

![](/img/wx.png)

![](/img/token.png)

## 油猴脚本填入Token
点击油猴图标进入管理面板

![](/img/tmptoken.png)

点击扩展的右方编辑按钮

![](/img/tmpedit.png)

在箭头的地方填入token并点击文件-保存

![](/img/tmpsuccess.png)

## 超星慕课小工具填入Token
在超星慕课小工具上填入token

![](/img/cxtoken.png)





