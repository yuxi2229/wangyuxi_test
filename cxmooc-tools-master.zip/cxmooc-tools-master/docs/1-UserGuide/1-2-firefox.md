---
title: FireFox扩展
---

本扩展上传至了火狐浏览器,可以直接在火狐浏览器的扩展商店进行下载

[FireFox商店](https://addons.mozilla.org/zh-CN/firefox/addon/%E8%B6%85%E6%98%9F%E6%85%95%E8%AF%BE%E5%B0%8F%E5%B7%A5%E5%85%B7/)

## 火狐浏览器扩展


如果你是火狐浏览器用户，请直接前往
[应用市场](https://addons.mozilla.org/zh-CN/firefox/addon/%E8%B6%85%E6%98%9F%E6%85%95%E8%AF%BE%E5%B0%8F%E5%B7%A5%E5%85%B7/)
下载安装扩展。

### 第一步
进入火狐浏览器页面点击【添加到FireFox】
![](/img/mozillapage.jpg)
### 第二步
点击添加

![](/img/mozillaadd.jpg)
### 第三步
右上方出现相应图标，点击弹出如下页面即为成功

然后打开网站正常刷课即可

![](/img/config.jpg)

### 附注
如果安装后弹出网址并显示【404 page not found】为正常现象，无须关注

## 火狐手机版(Android)
> 待完善,可以下载火狐浏览器app后在商店安装.
> 目前手机版环境复杂，推荐使用电脑挂机刷课

