---
title: FireFox扩展
---
## [推荐]火狐浏览器扩展

如果你是火狐浏览器用户，请直接前往
[应用市场](https://addons.mozilla.org/zh-CN/firefox/addon/%E8%B6%85%E6%98%9F%E6%85%95%E8%AF%BE%E5%B0%8F%E5%B7%A5%E5%85%B7/)
下载安装扩展。

*注意，本扩展支持Firefox for Mobile*

为了方便安装,我们还提供了一个浏览器打包的版本,请在[releases页面](https://github.com/CodFrm/cxmooc-tools/releases)查看详情

![](/img/4.webp)