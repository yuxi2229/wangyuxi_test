---
title: 油猴脚本
---

不再赘述，请自行配置使用。[油猴](https://bbs.tampermonkey.net.cn/thread-61-1-1.html)
