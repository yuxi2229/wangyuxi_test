<template>
  <footer>
  <div class="footer">
  <p>MIT Licensed | Copyright © 2018 CXmooc-tool developer Team</p><a href="http://www.miitbeian.gov.cn/" rel="external nofollow" target="_blank">湘ICP备19008073号</a>
  </div>
  </footer>
</template>