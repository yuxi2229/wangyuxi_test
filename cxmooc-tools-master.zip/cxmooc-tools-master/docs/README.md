---
home: true
heroImage: 
heroText: 超星慕课小工具
tagline: 方便 快捷 安全
actionText: 开始使用
actionLink: /1-UserGuide/
features:
- title: 功能齐全
  details: 支持视频挂机，自动答题，自动打码
- title: 支持广泛
  details: 支持Chrome浏览器扩展，油猴脚本等方式运行
- title: 安全可靠
  details: 代码完全开源，透明
---

![GitHub stars](https://img.shields.io/github/stars/codfrm/cxmooc-tools.svg)
[![Build Status](https://github.com/CodFrm/cxmooc-tools/workflows/build/badge.svg?branch=master)](https://github.com/CodFrm/cxmooc-tools)
![GitHub All Releases](https://img.shields.io/github/downloads/codfrm/cxmooc-tools/total.svg)
![GitHub tag (latest SemVer)](https://img.shields.io/github/tag/codfrm/cxmooc-tools.svg?label=version)
[![Chrome](https://img.shields.io/badge/chrome-success-brightgreen)](https://chrome.google.com/webstore/detail/%E8%B6%85%E6%98%9F%E6%85%95%E8%AF%BE%E5%B0%8F%E5%B7%A5%E5%85%B7/kkicgcijebblepmephnfganiiochecfl?hl=zh-CN)
[![FireFox](https://img.shields.io/badge/firefox-success-brightgreen)](https://addons.mozilla.org/zh-CN/firefox/addon/%E8%B6%85%E6%98%9F%E6%85%95%E8%AF%BE%E5%B0%8F%E5%B7%A5%E5%85%B7/)
[![tampermonkey](https://img.shields.io/badge/tampermonkey-success-yellowgreen)](https://bbs.tampermonkey.net.cn/thread-61-1-1.html)



## 关于超星慕课小工具
> 2.1版本以后开始支持智慧树,2.2版本以后开始支持中国大学mooc 名字嘛不改了

一个 超星(学习通)/智慧树(知到)/中国大学mooc 刷课工具,火狐,谷歌,油猴支持.全自动任务,视频倍速秒过,作业考试题库,验证码自动打码(੧ᐛ੭挂科模式,启动)

### 浏览器适配列表
> 国内大多数浏览器使用的chrome内核,所以360,QQ浏览器等之类的也可以使用
 * Chrome for PC
 * Firefox for PC
 * Firefox for Mobile
 * QQ 浏览器 for PC
 * Tampermonkey
 * Chrome 系浏览器

### 功能支持列表
**详情请看->[功能说明](/1-UserGuide/featured.html)**


<Footer/>